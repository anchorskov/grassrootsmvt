-- D1 Schema Sync
-- Generated: Thu Oct  9 08:16:26 MDT 2025
-- Source: wy → wy_preview

CREATE TABLE _cf_KV (;

        key TEXT PRIMARY KEY,;

        value BLOB;

      ) WITHOUT ROWID;

CREATE VIEW best_phone AS;

SELECT voter_id, phone_e164, confidence_code, is_wy_area, imported_at;

FROM v_best_phone;

CREATE TABLE call_activity (;

  id INTEGER PRIMARY KEY AUTOINCREMENT,;

  ts TEXT NOT NULL,;

  voter_id TEXT,;

  outcome TEXT,;

  volunteer_email TEXT,;

  payload_json TEXT;

);

CREATE TABLE call_assignments (;

  voter_id TEXT PRIMARY KEY,;

  volunteer_id TEXT NOT NULL,;

  locked_at DATETIME DEFAULT CURRENT_TIMESTAMP,;

  lock_expires_at DATETIME;

);

CREATE TABLE call_followups (;

  id INTEGER PRIMARY KEY AUTOINCREMENT,;

  voter_id TEXT NOT NULL,;

  due_date DATE,;

  reason TEXT,                    -- 'requested_info','callback_window','other';

  created_by TEXT NOT NULL,;

  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,;

  done INTEGER DEFAULT 0;

);

CREATE TABLE d1_migrations(;

		id         INTEGER PRIMARY KEY AUTOINCREMENT,;

		name       TEXT UNIQUE,;

		applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL;

);

CREATE INDEX idx_call_activity_vid ON call_activity(voter_id);

CREATE INDEX idx_v_best_phone_phone ON v_best_phone(phone_e164);

CREATE INDEX idx_v_voters_addr_norm_city ON v_voters_addr_norm(city);

CREATE INDEX idx_v_voters_addr_norm_zip ON v_voters_addr_norm(zip);

CREATE INDEX idx_voters_county ON voters(county);

CREATE INDEX idx_voters_party ON voters(political_party);

CREATE TABLE message_templates (;

  id TEXT PRIMARY KEY,;

  channel TEXT NOT NULL,          -- 'pdf','email','sms';

  audience TEXT,                  -- 'R','D','U','All';

  body_html TEXT NOT NULL;

);

CREATE TABLE sqlite_sequence(name,seq);

CREATE TABLE v_best_phone (;

  voter_id TEXT PRIMARY KEY,;

  phone_e164 TEXT,;

  confidence_code INTEGER,;

  is_wy_area INTEGER,;

  imported_at TEXT;

);

CREATE TABLE "v_best_phone_old" (;

  voter_id TEXT PRIMARY KEY,;

  phone_e164 TEXT;

);

CREATE VIEW v_eligible_call AS;

SELECT r.voter_id, r.first_name, r.last_name, r.ra_city, r.ra_zip,;

       n.party_form5 AS party, bp.phone_e164,;

       '1900-01-01' AS last_contact_at;

FROM voters_raw r;

JOIN voters_norm n USING(voter_id);

LEFT JOIN "v_best_phone_old" bp USING(voter_id);

CREATE TABLE v_voters_addr_norm (;

  voter_id TEXT PRIMARY KEY,;

  ln TEXT,;

  fn TEXT,;

  addr1 TEXT,;

  city TEXT,;

  state TEXT,;

  zip TEXT,;

  senate TEXT,;

  house TEXT;

);

CREATE TABLE volunteers (;

  id   TEXT PRIMARY KEY,     -- email from Cloudflare Access;

  name TEXT NOT NULL;

);

CREATE TABLE voter_contacts (;

  id INTEGER PRIMARY KEY AUTOINCREMENT,;

  voter_id TEXT NOT NULL,;

  volunteer_id TEXT NOT NULL,;

  method TEXT NOT NULL,           -- 'phone' | 'door';

  outcome TEXT NOT NULL,          -- 'connected','vm','no_answer','wrong_number','refused','follow_up';

  ok_callback INTEGER,;

  best_day TEXT,;

  best_time_window TEXT,;

  requested_info INTEGER,;

  dnc INTEGER,;

  optin_sms INTEGER,;

  optin_email INTEGER,;

  email TEXT,;

  wants_volunteer INTEGER,;

  share_insights_ok INTEGER,;

  for_term_limits INTEGER,;

  issue_public_lands INTEGER,;

  comments TEXT,;

  created_at DATETIME DEFAULT CURRENT_TIMESTAMP;

);

CREATE TABLE voters (;

  voter_id TEXT PRIMARY KEY,;

  political_party TEXT,;

  county TEXT,;

  senate TEXT,;

  house TEXT;

);

CREATE VIEW voters_addr_norm AS;

SELECT voter_id, ln, fn, addr1, city, state, zip, senate, house;

FROM v_voters_addr_norm;

CREATE TABLE voters_norm (;

  voter_id TEXT PRIMARY KEY,;

  party_form5 TEXT;

, reg_year INTEGER);

CREATE TABLE voters_raw (;

  voter_id TEXT PRIMARY KEY,;

  first_name TEXT, last_name TEXT, ra_city TEXT, ra_zip TEXT;

, county   TEXT, precinct TEXT, house    TEXT, senate   TEXT);

CREATE TABLE walk_assignments (;

  batch_id INTEGER NOT NULL,;

  voter_id TEXT NOT NULL,;

  position INTEGER,;

  PRIMARY KEY (batch_id, voter_id);

);

CREATE TABLE walk_batches (;

  id INTEGER PRIMARY KEY AUTOINCREMENT,;

  volunteer_id TEXT NOT NULL,;

  county TEXT, city TEXT, district TEXT, precinct TEXT,;

  created_at DATETIME DEFAULT CURRENT_TIMESTAMP;

);

